echo "(1)Download application or (2) Download page web: "
read a

if [ $a == "1" ]
then
	echo "enter link application: "
	read b
	echo "loding....."
	git clone $b
fi

if [ $a == "1" ]
then
	echo "enter link page web: "
	read c
	echo "loding...."
	wget $c
