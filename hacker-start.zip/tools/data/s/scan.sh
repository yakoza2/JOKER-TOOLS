while true
do
echo "[+]@ "
read s
if [ $s == "-h" ]
then
	echo "-i Download Packages"
	echo "-h help"
	echo "-ss Simple Scaning"
	echo "-ps Port scaning"
	echo "-v System The Target"
fi
if [ $s == "-i" ]
then
	pkg install nmap
	echo "OK ^_^"
fi
if [ $s == "-ss" ]
then
	echo "Enter IP: "
	read q
	nmap $q
fi
if [ $s == "-ps" ]
then
	echo "Enter IP: "
	read w
	echo "Enter PORT: "
	read e
	nmap $w -p $e
fi
if [ $s == "-v" ]
then
	echo "Enter ip: "
	read u
	nmap -V $u
fi
done

